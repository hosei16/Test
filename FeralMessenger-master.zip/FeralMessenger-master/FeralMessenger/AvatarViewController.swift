//
//  AvatarViewController.swift
//  FeralMessenger
//
//  Created by rightmeow on 6/30/17.
//  Copyright © 2017 Duckisburg. All rights reserved.
//

import UIKit


class AvatarViewController: DisclosureViewController {
    
    // MARK: - Parse
    
    
    
}
