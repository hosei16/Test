//
//  NotificationCell.swift
//  FeralMessenger
//
//  Created by rightmeow on 6/17/17.
//  Copyright © 2017 Duckisburg. All rights reserved.
//

import UIKit


class NotificationCell: UITableViewCell {
    
    static let id = "NotificationCell"
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
}
