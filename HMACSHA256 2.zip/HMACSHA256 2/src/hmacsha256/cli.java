/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hmacsha256;

/**
 *
 * @author dewbabyo
 */
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;
public class cli {
    
    public static void main (String [] args) throws IOException
    {
    String hash,temp;
    Scanner sc = new Scanner(System.in);
    Socket s;
        s = new Socket("69.137.63.110",1342);
    Scanner sc1 = new Scanner(s.getInputStream());
    System.out.println("Enter HMAC hash");
    hash = sc.nextLine();
    
    PrintStream p= new PrintStream(s.getOutputStream());
    p.println(hash);
    
    temp=sc1.nextLine();
    
    System.out.println(temp);
    
    }
}
