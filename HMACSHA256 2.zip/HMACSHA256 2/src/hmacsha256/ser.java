/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hmacsha256;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author dewbabyo
 */
public class ser {
    public static void main (String [] args) throws IOException
    {
    String hash,temp;
    ServerSocket s1 = new ServerSocket(1342);
    Socket ss =s1.accept();
    Scanner sc = new Scanner(ss.getInputStream());
    hash = sc.nextLine();
    
    temp = hash;
    
    PrintStream p = new PrintStream(ss.getOutputStream());
    
    p.println(temp);
    
    
    }
}
