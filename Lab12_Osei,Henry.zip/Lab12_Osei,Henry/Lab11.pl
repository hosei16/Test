$arg1 = "hello";
$arg2 = "\x50\x10\x40";
$cmd = "./Lab11.c ";
system($cmd.$arg1.$arg2);
